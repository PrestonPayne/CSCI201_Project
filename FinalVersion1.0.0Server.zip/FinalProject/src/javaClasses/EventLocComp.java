package javaClasses;

import java.util.Comparator;

public class EventLocComp implements Comparator<Event>{
	double lat;
	double lng;
	
	public EventLocComp(double lat, double lng) {
		this.lat = lat;
		this.lng = lng;
	}

	@Override
	public int compare(Event e1, Event e2) {
		Double dist1 = Util.distFrom(e1.getLat(), e1.getLng(), lat, lng);
		Double dist2 = Util.distFrom(e2.getLat(), e2.getLng(), lat, lng);
		return dist1.compareTo(dist2);
	}

}
