package javaClasses;

/**
 * Created by Zhao on 11/24/2017.
 */

public class Util {
    public static final int VERIFY_USER = 1;
    public static final int CREATE_NEW_ACOUNT = 2;
    public static final int GET_EVENTS = 3;
    public static final int SEARCH_USER = 4;
    public static final int GET_EVENT_OF_USER =5;
    public static final int CREATE_EVENT = 6;
    public static final int CHANGE_NAME = 7;
    public static final int GET_MEMBER = 8;
    public static final int JOIN = 9;

    public Util(){

    }
    
    public static double distFrom(double lat1, double lng1, double lat2, double lng2) {
        double earthRadius = 6371000; 
        double dLat = Math.toRadians(lat2-lat1);
        double dLng = Math.toRadians(lng2-lng1);
        double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
                   Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                   Math.sin(dLng/2) * Math.sin(dLng/2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
        double dist = earthRadius * c;
        return dist;
    }
}
