package javaClasses;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Prest`on on 11/13/2017.
 */

public class User implements Serializable{
    private static final long serialVersionUID = 1;
    protected double lat;
    protected double lng;
    protected boolean isRegistered;

    public User(){
        isRegistered = false;
    }

    public User(double lat, double lng) {
        isRegistered = false;
        this.lat = lat;
        this.lng = lng;
    }

    public boolean isRegistered(){
        return isRegistered;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }



}
