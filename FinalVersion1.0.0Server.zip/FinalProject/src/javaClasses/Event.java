package javaClasses;


import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.sql.Time;
import java.util.Calendar;

/**
 * Created by Preston on 11/13/2017.
 */

public class Event implements Serializable {

    private static final long serialVersionUID = 1;
    private int id;
    private Time myTime;
    private Date myDate;
    private String myTitle;
    private String description;
    private double lat;
    private double lng;

    public Event(int id, Time time, Date date, String title, String description, double lat, double lng) {
        this.id = id;
        this.myTime = time;
        this.myDate = date;
        this.myTitle = title;
        this.description = description;
        this.lat = lat;
        this.lng = lng;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Event(Date date){
        Date myDate = date;
    }

    public double getLat() {
        return lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public double getLng() {
        return lng;
    }

    public void setLng(double lng) {
        this.lng = lng;
    }

    public Time getTime() {
        return myTime;
    }

    public void setTime(Time time) {
        myTime = time;
    }

    public Date getDate() {
        return myDate;
    }

    public void setDate(java.sql.Date date) {
        myDate = date;
    }

    public String getDateString(){
        SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
        return sdf.format(myDate) + " " + myTime.toString();
    }

    public String getTitle() {
        return myTitle;
    }

    public void setTitle(String title) {
        myTitle = title;
    }

    public void setDescription(String description){
        this.description = description;
    }

    public String getDescription(){
        return description;
    }
}
