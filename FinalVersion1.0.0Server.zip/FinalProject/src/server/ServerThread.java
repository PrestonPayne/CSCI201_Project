package server;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;

import org.json.JSONObject;

import javaClasses.Event;
import javaClasses.EventLocComp;
import javaClasses.RegisteredUser;
import javaClasses.Util;

/**
 * Created by Preston on 11/18/2017.
 */

public class ServerThread extends Thread{

    private ObjectInputStream ois;
    private ObjectOutputStream oos;
    private Server myServer;

    public ServerThread(Socket s, Server server){
        try{
            this.myServer = server;
            oos = new ObjectOutputStream(s.getOutputStream());
            ois = new ObjectInputStream(s.getInputStream());
            this.start();
        }catch (IOException e){
            System.out.println("IOE: " + e.getMessage());
        }
    }


    /*
    public void run(){
        try{
            while(true){
                Query query = (Query) ois.readObject();
                String script = query.getMyScript();
                System.out.println("mySQL Script:" + script);
                int type = query.getMyType();
                Connection conn = null;
                Statement st = null;
                ResultSet rs = null;
                switch(type){
                    case 1:
                        try{
                            Class.forName("com.mysql.jdbc.Driver");
                            conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproject?user=root&password=root&useSSL=false");
                            st = conn.createStatement();
                            rs = st.executeQuery(script);
                            RegisteredUser u = null;
                            if(!rs.next()){
                                oos.writeObject(u);
                                break;
                            }
                            u =  new RegisteredUser(rs.getString("user_name"), rs.getInt("user_age"), rs.getInt("user_id"), rs.getString("user_email"), rs.getBoolean("user_gender"), rs.getString("user_pw"));
                            oos.writeObject(u);
                        } catch (SQLException sqle){
                            System.out.println("sqle: " + sqle.getMessage());
                            break;
                        }
                        break;
                    case 2: 
                        try{
                            Class.forName("com.mysql.jdbc.Driver");
                            conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproject?user=root&password=root&useSSL=false");
                            st = conn.createStatement();
                            rs = st.executeQuery(script);
                            Event e = null;
                            if(!rs.next()){
                                oos.writeObject(e);
                                break;
                            }
                            int creatorID = rs.getInt("user_id");
                            rs = st.executeQuery("SELECT u.user_name, u.user_age, u.user_id, u.user_email, u.user_gender, u.user_pw FROM user_ u WHERE u.user_id = " + creatorID + ";");
                            RegisteredUser u =  new RegisteredUser(rs.getString("user_name"), rs.getInt("user_age"), rs.getInt("user_id"), rs.getString("user_email"), rs.getBoolean("user_gender"), rs.getString("user_pw"));
                            
                            //TODO: instantiate event
                            oos.writeObject(e);
                        } catch (SQLException sqle){
                            System.out.println("sqle: " + sqle.getMessage());
                            break;
                        }
                        break;
                    case 3: 
                        try{
                            Class.forName("com.mysql.jdbc.Driver");
                            conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproject?user=root&password=root&useSSL=false");
                            st = conn.createStatement();
                            rs = st.executeQuery(script);
                            Comment c = null;
                            if(!rs.next()){
                                oos.writeObject(c);
                                break;
                            }
                            //TODO: instantiate comment
                            oos.writeObject(c);
                        } catch (SQLException sqle){
                            System.out.println("sqle: " + sqle.getMessage());
                            break;
                        }
                        break;
                    case 4: 
                        try{
                            Class.forName("com.mysql.jdbc.Driver");
                            conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproject?user=root&password=root&useSSL=false");
                            st = conn.createStatement();
                            int result = st.executeUpdate(script);
                            System.out.println(result);
                            if(result == 0) {
                            	oos.writeObject(new Boolean(false));;
                            } else {
                            	oos.writeObject(new Boolean(true));;
                            }
                        } catch (SQLException sqle){
                            System.out.println("sqle: " + sqle.getMessage());
                            break;
                        }
                        break;
                }
            }
        }catch (IOException ioe){
            System.out.println(ioe.getMessage());
        }catch (ClassNotFoundException cnfe){
            System.out.println("CNFE: " + cnfe.getMessage());
        }



    }*/
    
    public void run(){
        try{
            Connection conn = null;
            Class.forName("com.mysql.jdbc.Driver");
            conn = DriverManager.getConnection("jdbc:mysql://localhost/finalproject?user=root&password=root&useSSL=false");
            while(true){
                String str = (String) ois.readObject();
                JSONObject query = new JSONObject(str);
                int type = query.getInt("type");
                switch(type) {
                	case Util.VERIFY_USER:{
                		Statement st = conn.createStatement();
                		JSONObject user = new JSONObject();
                		user.put("isValid", false);
                		ResultSet rs = st.executeQuery("SELECT * FROM User_ u WHERE u.user_name = '" + query.getString("username") + "' AND u.user_pw = '" + query.getString("password") + "';");
                		if(rs.next()) {
                			user = new JSONObject();
                			user.put("isValid", true);
                			user.put("id", rs.getInt("user_id"));
                			user.put("username", rs.getString("user_name"));
                			user.put("pw", rs.getString("user_pw"));
                			user.put("email", rs.getString("user_email"));
                			user.put("age", rs.getInt("user_age"));
                			user.put("gender", rs.getBoolean("user_gender"));
                			user.put("lat", rs.getDouble("user_lat"));
                			user.put("lng", rs.getDouble("user_lng"));
                		}
                		oos.writeObject(user.toString());
            			oos.flush();
                		rs.close();
                		break;
                	}
                	case Util.CREATE_NEW_ACOUNT: {
                		Statement st = conn.createStatement();
                		ResultSet rs = null;
                		JSONObject user = new JSONObject();
                		user.put("isValid", false);
                		int row = st.executeUpdate("INSERT INTO User_ (user_name, user_pw, user_email, user_age, user_gender, user_lat, user_lng) VALUES ('" + 
                								   query.getString("username") + "', '" + query.getString("password") + "', '" + query.getString("email") + "', " + 
                								   query.getInt("age") + ", " + (query.getBoolean("gender") ? 1 : 0) + ", " + query.getDouble("lat") + ", " + query.getDouble("lng") + ");");
                		if(row != 0) {
                			rs = st.executeQuery("SELECT LAST_INSERT_ID();");
                			rs.next();
                			int id = rs.getInt("LAST_INSERT_ID()");
                			rs.close();
                			user.put("isValid", true);
                			user.put("id", id);
                			user.put("username", query.getString("username"));
                			user.put("pw", query.getString("password"));
                			user.put("email", query.getString("email"));
                			user.put("age", query.getInt("age"));
                			user.put("gender", query.getBoolean("gender"));
                			user.put("lat", query.getDouble("lat"));
                			user.put("lng", query.getDouble("lng"));
                		}
                		oos.writeObject(user.toString());
            			oos.flush();
                		rs.close();
                		break;
                	}
                	case Util.GET_EVENTS: {
                		Statement st = conn.createStatement();
                		ResultSet rs = st.executeQuery("SELECT * FROM event_;");
                		ArrayList<Event> events = new ArrayList<Event>();
                		while(rs.next()) {
                			Event e = new Event(rs.getInt("event_id"), rs.getTime("event_time"), rs.getDate("event_date"), rs.getString("event_title"), rs.getString("event_des"), rs.getDouble("event_lat"), rs.getDouble("event_lng"));
                			events.add(e);
                		}
                		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
                		oos.writeInt(events.size());
            			oos.flush();
                		for(int i = 0; i < events.size(); i++) {
                			Event e = events.get(i);
                			JSONObject obj = new JSONObject();
                			obj.put("id", e.getId());
                			obj.put("time", e.getTime().toString());
                			obj.put("date", sdf.format(e.getDate()));
                			obj.put("title", e.getTitle());
                			obj.put("des", e.getDescription());
                			obj.put("lat", e.getLat());
                			obj.put("lng", e.getLng());
                			oos.writeObject(obj.toString());
                			oos.flush();
                		}
                		rs.close();
                		break;
                	}
                	case Util.SEARCH_USER: {
                		Statement st = conn.createStatement();
                		String keyword = query.getString("keyword");
                		ResultSet rs = st.executeQuery("SELECT * FROM user_;");
                		ArrayList<RegisteredUser> results = new ArrayList<RegisteredUser>();
                		while(rs.next()) {
                			if(rs.getString("user_name").contains(keyword)) {
                				results.add(new RegisteredUser(rs.getString("user_name"), rs.getInt("user_age"), rs.getInt("user_id"), rs.getString("user_email"), 
                											   rs.getBoolean("user_gender"),rs.getString("user_pw"), rs.getDouble("user_lat"), rs.getDouble("user_lng")));
                			}
                		}
                		oos.writeInt(results.size());
            			oos.flush();
                		for(RegisteredUser u: results) {
                			JSONObject user = new JSONObject();
                			user.put("id", u.getUserID());
                			user.put("username", u.getName());
                			user.put("pw", u.getPassword());
                			user.put("email", u.getEmail());
                			user.put("age", u.getAge());
                			user.put("gender", u.getGender());
                			user.put("lat", u.getLat());
                			user.put("lng", u.getLng());
                			oos.writeObject(user.toString());
                			oos.flush();
                		}
                		rs.close();
                		break;
                	}
                	case Util.GET_EVENT_OF_USER: {
                		Statement st= conn.createStatement();
                		int id = query.getInt("id");
                		ResultSet rs = st.executeQuery("SELECT * FROM event_ WHERE user_id = " + id + ";");
                		ArrayList<Event> events = new ArrayList<Event>();
                		while(rs.next()) {
                			Event e = new Event(rs.getInt("event_id"), rs.getTime("event_time"), rs.getDate("event_date"), rs.getString("event_title"), rs.getString("event_des"), rs.getDouble("event_lat"), rs.getDouble("event_lng"));
                			events.add(e);
                		}
                		oos.writeInt(events.size());
            			oos.flush();
                		SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-YYYY");
                		for(Event e: events) {
                			JSONObject obj = new JSONObject();
                			obj.put("id", e.getId());
                			obj.put("time", e.getTime().toString());
                			obj.put("date", sdf.format(e.getDate()));
                			obj.put("title", e.getTitle());
                			obj.put("des", e.getDescription());
                			obj.put("lat", e.getLat());
                			obj.put("lng", e.getLng());
                			oos.writeObject(obj.toString());
                			oos.flush();
                		}
                		rs.close();
                		break;
                	}
                	case Util.CREATE_EVENT: {
                		Statement st = conn.createStatement();
                		int row = st.executeUpdate("INSERT INTO event_ (event_time, event_date, event_title, event_des, event_lat, event_lng, user_id) VALUES ('" +
                									query.getString("time") + "', '" + query.getString("date") + "', '" + query.getString("title") + "', '" + 
                									query.getString("des") + "', " + query.getDouble("lat") + ", " + query.getDouble("lng") + ", " + query.getInt("userId") + ");");
                		if(row == 0) {
                			oos.writeBoolean(false);
                			oos.flush();
                		} else {
                			oos.writeBoolean(true);
                			oos.flush();
                		}
                		break;
                	}
                	case Util.CHANGE_NAME:{
                		Statement st = conn.createStatement();
                		ResultSet rs = st.executeQuery("SELECT user_id FROM user_ WHERE user_name = '" + query.getString("name") + "';");
                		if(rs.next()) {
                			oos.writeBoolean(false);
                			oos.flush();
                			break;
                		}
                		int row = st.executeUpdate("UPDATE User_ SET user_name = '" + query.getString("name") + "' WHERE user_id = " + query.getInt("id") + ";");
            			oos.writeBoolean(true);
            			oos.flush();
                		break;
                	}
                	case Util.GET_MEMBER: {
                		Statement st = conn.createStatement();
                		ArrayList<RegisteredUser> users = new ArrayList<RegisteredUser>();
                		ResultSet rs = st.executeQuery("SELECT * FROM user_ u, event_ e WHERE u.user_id = e.user_id AND e.event_id = " + query.getInt("id") + ";");
                		rs.next();
                		users.add(new RegisteredUser(rs.getString("user_name"), rs.getInt("user_age"), rs.getInt("user_id"), rs.getString("user_email"), 
								   rs.getBoolean("user_gender"),rs.getString("user_pw"), rs.getDouble("user_lat"), rs.getDouble("user_lng")));
                		rs.close();
                		Statement st2 = conn.createStatement();
                		ResultSet rs2 = st2.executeQuery("SELECT * FROM user_ u, Event_Member em WHERE em.user_id = u.user_id AND em.event_id = " + query.getInt("id") + ";");
                		while(rs2.next()) {
                    		users.add(new RegisteredUser(rs2.getString("user_name"), rs2.getInt("user_age"), rs2.getInt("user_id"), rs2.getString("user_email"), 
    								   rs2.getBoolean("user_gender"),rs2.getString("user_pw"), rs2.getDouble("user_lat"), rs2.getDouble("user_lng")));
                		}
                		oos.writeInt(users.size());
                		oos.flush();
                		for(RegisteredUser u: users) {
                			JSONObject user = new JSONObject();
                			user.put("id", u.getUserID());
                			user.put("username", u.getName());
                			user.put("pw", u.getPassword());
                			user.put("email", u.getEmail());
                			user.put("age", u.getAge());
                			user.put("gender", u.getGender());
                			user.put("lat", u.getLat());
                			user.put("lng", u.getLng());
                			oos.writeObject(user.toString());
                			oos.flush();
                		}
                		break;
                	}
                	case Util.JOIN: {
                		Statement st = conn.createStatement();
                		int row = st.executeUpdate("INSERT INTO Event_Member (event_id, user_id) VALUES (" + query.getInt("event_id") + ", " + query.getInt("user_id") + ")");
                		if(row == 0) {
                			oos.writeBoolean(false);
                			oos.flush();
                		} else {
                			oos.writeBoolean(true);
                			oos.flush();
                		}
                		break;
                	}
                }
            }
        } catch (IOException ioe){
            System.out.println("ioe:" + ioe.getMessage());
        } catch (ClassNotFoundException cnfe){
            System.out.println("CNFE: " + cnfe.getMessage());
        } catch (SQLException sqle){
            System.out.println("sqle: " + sqle.getMessage());
        }
    }
   
    
}
