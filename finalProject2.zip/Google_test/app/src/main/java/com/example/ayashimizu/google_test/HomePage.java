package com.example.ayashimizu.google_test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class HomePage extends AppCompatActivity {

    private Button createEventButton;
    private Button search;
    private Button account;
    private Button notifications;
    private Button settings;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        LinearLayout middle = (LinearLayout) findViewById(R.id.ttt4);

        init();

        //get list of all event objects
        for(int i=0; i<5; i++){
            LinearLayout event1 = new LinearLayout(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,250);
            event1.setLayoutParams(params);
            event1.setOrientation(LinearLayout.VERTICAL);
            event1.setGravity(Gravity.CENTER);

            TextView name = new TextView(this);
            String text2 = "Title " + i; //string title of event
            name.setText(text2);
            name.setHeight(70);
            name.setWidth(315);
            name.setGravity(Gravity.CENTER);
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            event1.addView(name);

            TextView date = new TextView(this);
            String text = "Event On: " + i; //string time and date of event
            date.setText(text);
            date.setHeight(50);
            date.setWidth(315);
            date.setGravity(Gravity.CENTER);
            date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            event1.addView(date);

            TextView description = new TextView(this);
            String text3 = "Description " + i; //string description of event
            description.setText(text3);
            description.setHeight(100);
            description.setWidth(315);
            description.setGravity(Gravity.CENTER);
            description.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            event1.addView(description);

            middle.addView(event1);
        }



    }

    public void init(){
        //if current user != null
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(HomePage.this, MapsActivity.class);
                startActivity(toy);
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(HomePage.this, Search.class);
                startActivity(toy);
            }
        });

        //if current user != null
        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(HomePage.this, Account.class);
                startActivity(toy);
            }
        });

        //if current user != null
        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(HomePage.this, Notifications.class);
                startActivity(toy);
            }
        });

        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(HomePage.this, Settings.class);
                startActivity(toy);
            }
        });
    }
}
