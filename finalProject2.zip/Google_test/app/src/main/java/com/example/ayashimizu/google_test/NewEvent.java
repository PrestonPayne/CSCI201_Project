package com.example.ayashimizu.google_test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class NewEvent extends AppCompatActivity {

    private Button createEventButton;
    private Button search;
    private Button home;
    private Button notifications;
    private Button settings;
    private Button account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);

        LinearLayout middle = (LinearLayout) findViewById(R.id.ttt4);
        TextView box = new TextView(this);
        String text = "Username's Account";
        box.setText(text);
        box.setHeight(200);
        box.setWidth(40);
        box.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
        box.setGravity(Gravity.CENTER);
        middle.addView(box);

        //get the event object of the most recently created event (size-1) in user's events

            LinearLayout event1 = new LinearLayout(this);
            LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,250);
            event1.setLayoutParams(params);
            event1.setOrientation(LinearLayout.VERTICAL);
            event1.setGravity(Gravity.CENTER);

            TextView name = new TextView(this);
            String text2 = "Title of New Event"; //get string title of event
            name.setText(text2);
            name.setHeight(70);
            name.setWidth(315);
            name.setGravity(Gravity.CENTER);
            name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
            event1.addView(name);

            TextView date = new TextView(this);
            String text4 = "Event time/date "; //get string time/date of event
            date.setText(text4);
            date.setHeight(50);
            date.setWidth(315);
            date.setGravity(Gravity.CENTER);
            date.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            event1.addView(date);

            TextView description = new TextView(this);
            String text3 = "Description"; //get string description of event
            description.setText(text3);
            description.setHeight(100);
            description.setWidth(315);
            description.setGravity(Gravity.CENTER);
            description.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
            event1.addView(description);

            middle.addView(event1);



        init();
    }

    public void init(){
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this, MapsActivity.class);
                startActivity(toy);
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this, Search.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this, HomePage.class);
                startActivity(toy);
            }
        });

        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this, Notifications.class);
                startActivity(toy);
            }
        });

        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this, Settings.class);
                startActivity(toy);
            }
        });

        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this,  Account.class);
                startActivity(toy);
            }
        });

    }
}
