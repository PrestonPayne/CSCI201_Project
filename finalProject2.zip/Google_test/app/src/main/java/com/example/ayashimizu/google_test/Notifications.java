package com.example.ayashimizu.google_test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class Notifications extends AppCompatActivity {

    private Button createEventButton;
    private Button search;
    private Button home;
    private Button settings;
    private Button account;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notifications);

        LinearLayout allNotifications = (LinearLayout) findViewById(R.id.ttt4);

        //get list of user's events and a few more
        for(int i=0; i<4; i++) {
            TextView box = new TextView(this);
            String text = "event title " + i; //string title of event
            box.setText(text);
            box.setHeight(200);
            box.setWidth(40);
            box.setGravity(Gravity.CENTER);
            allNotifications.addView(box);
        }

        init();



    }

    public void init(){
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Notifications.this, MapsActivity.class);
                startActivity(toy);
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Notifications.this, Search.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Notifications.this, HomePage.class);
                startActivity(toy);
            }
        });

        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Notifications.this, Settings.class);
                startActivity(toy);
            }
        });

        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Notifications.this, Account.class);
                startActivity(toy);
            }
        });
    }
}
