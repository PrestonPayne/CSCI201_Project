package com.example.ayashimizu.google_test;

import android.annotation.SuppressLint;
import android.os.StrictMode;
import android.util.Log;

import com.google.android.gms.analytics.ExceptionParser;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 * Created by ayashimizu on 11/11/17.
 */

//public class ConnectionClass {
//
//    @SuppressLint("NewApi")
//    public Connection CONN(){
//        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder()
//                .permitAll().build();
//        StrictMode.setThreadPolicy(policy);
//
//    }
//
//}
