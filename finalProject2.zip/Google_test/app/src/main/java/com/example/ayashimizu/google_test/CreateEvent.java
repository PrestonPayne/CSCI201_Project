package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CreateEvent extends AppCompatActivity {

    private Button settings;
    private Button search;
    private Button home;
    private Button notifications;
    private Button account;
    private Button create;

    private EditText titleBlock;
    private EditText timeDateBlock;
    private EditText locationBlock;
    private EditText descriptionBlock;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event2);

        init();
    }

    public void init(){
        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Settings.class);
                startActivity(toy);
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Search.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, HomePage.class);
                startActivity(toy);
            }
        });

        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Notifications.class);
                startActivity(toy);
            }
        });

        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Account.class);
                startActivity(toy);
            }
        });

        create = findViewById(R.id.create);
        create.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
            titleBlock = findViewById(R.id.title);
            timeDateBlock = findViewById(R.id.timeDate);
            locationBlock = findViewById(R.id.location);
            descriptionBlock = findViewById(R.id.description);

                String title = titleBlock.getText().toString();
                String error = "";
                if(title.length() == 0){
                    error = error + "Please enter title" + '\n';
                }

                String timeDate = timeDateBlock.getText().toString();
                if(timeDate.length() == 0){
                    error = error + "Please enter a time and date" + '\n';
                }

                String location = locationBlock.getText().toString();
                if(location.length() < 0){
                    error = error + "Please enter location";
                }

                String description = descriptionBlock.getText().toString();
                if(description.length() < 0){
                    error = error + "Please enter description";
                }

                if(error.length() == 0){
                    //create a new event obj with the parameters of the fields and add to database
                    Intent toy = new Intent(CreateEvent.this, NewEvent.class);
                    startActivity(toy);
                }

                else{
                    AlertDialog.Builder alert = new AlertDialog.Builder(CreateEvent.this);
                    alert.setTitle("Invalid Fields");

                    alert.setMessage(error)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    startActivity(new Intent(CreateEvent.this, CreateEvent.class));
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                }

            }
        });
    }
}
