package com.example.ayashimizu.google_test;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.net.URI;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MainActivity extends FragmentActivity {

    private Button loginButton;
    private Button createAccountButton;
    private Button unregisteredUserButton;
    private EditText usernameBlock;
    private EditText passwordBlock;
    private String username;
    private String password;


    ProgressDialog progressDialog;

    public void init() {
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        unregisteredUserButton = findViewById(R.id.unregisteredUserButton);
        usernameBlock = findViewById(R.id.username);
        passwordBlock = findViewById(R.id.password);
        unregisteredUserButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {

                Intent toy = new Intent(MainActivity.this, HomePage.class);
                startActivity(toy);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {

            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent toy = new Intent(MainActivity.this, CreateAccountActivity.class);
                startActivity(toy);

            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //connectionClass = new ConnectionClass();
        init();

    }


}


