package com.example.ayashimizu.google_test;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Settings extends AppCompatActivity {

    private Button createEventButton;
    private Button search;
    private Button home;
    private Button notifications;
    private Button account;
    private Button logout;
    private EditText newName;
    private Button changeName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        init();

    }

    public void init(){
        //if current user != null
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, MapsActivity.class);
                startActivity(toy);
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, Search.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, HomePage.class);
                startActivity(toy);
            }
        });

        //if current user != null
        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, Notifications.class);
                startActivity(toy);
            }
        });

        //if current user != null
        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, Account.class);
                startActivity(toy);
            }
        });

        logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, MainActivity.class);
                startActivity(toy);
            }
        });

        //if current user != null
        newName = findViewById(R.id.newName);
        changeName = findViewById(R.id.changeName);
        changeName.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                String name = newName.getText().toString();
                //set user's username to name
                newName.setText("");
            }
        });
    }
}
