package com.example.ayashimizu.google_test;

import android.app.Fragment;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.support.v4.app.DialogFragment;
import android.widget.Spinner;

public class CreateAccountActivity extends FragmentActivity {

    private EditText usernameBlock;
    private EditText passwordBlock;
    private EditText emailBlock;
    private EditText ageBlock;
    private Button createButton;
    private Spinner genderBlock;

    public void init() {
        usernameBlock = findViewById(R.id.username);
        passwordBlock = findViewById(R.id.password);
        emailBlock = findViewById(R.id.email);
        ageBlock = findViewById(R.id.age);
        genderBlock = (Spinner)findViewById(R.id.gender);
        String[] items = new String[]{"Female", "Male"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        genderBlock.setAdapter(adapter);
        createButton = findViewById(R.id.create);
        createButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {

                String username = usernameBlock.getText().toString();
                String error = "";
                if(username.length() == 0){
                    error = error + "Please enter username" + '\n';
                }

                String password = passwordBlock.getText().toString();
                if(password.length() < 8){
                    error = error + "Password must be longer than 8 characters" + '\n';
                }

                String email = emailBlock.getText().toString();
                if(email.length() < 0){
                    error = error + "Please enter valid email address";
                }

                String ageStr = ageBlock.getText().toString();
                try {
                    int age = Integer.parseInt(ageStr);
                    if(age <= 0 || age > 999){
                        error = error + "Please enter valid age";
                    }
                } catch (NumberFormatException e) {
                    error = error + "Please enter valid age";
                }

                String gender = genderBlock.getSelectedItem().toString();

                if(error.length() == 0){
                    Intent toy = new Intent(CreateAccountActivity.this, MapsActivity.class);
                    startActivity(toy);
                }

                else{
                    AlertDialog.Builder alert = new AlertDialog.Builder(CreateAccountActivity.this);
                    alert.setTitle("Invalid Fields");

                    alert.setMessage(error)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    startActivity(new Intent(CreateAccountActivity.this, CreateAccountActivity.class));
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                }

            }
        });

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_account);

        init();
    }
}
