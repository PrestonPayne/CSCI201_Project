package javaClasses;

import java.io.Serializable;
import java.util.ArrayList;

/**
 * Created by Preston on 11/13/2017.
 */

public class RegisteredUser extends User implements Serializable{

    private static final long serialVersionUID = 1;
    private int myUserID;
    private String myName;
    private String myPassword;
    private String myEmail;
    private int myAge;
    private boolean myGender;

    public RegisteredUser(String name, int age, int userID, String email, boolean gender, String password, double lat, double lng){
        isRegistered = true;
        myName = name;
        myAge = age;
        myUserID = userID;
        myEmail = email;
        myGender = gender;
        myPassword = password;
        this.lat = lat;
        this.lng = lng;
    }

    public String getGenderString(){
        if(myGender){
            return "Male";
        } else {
            return "Female";
        }
    }

    public int getAge() {
        return myAge;
    }

    public void setAge(int myAge) {
        this.myAge = myAge;
    }

    public int getUserID() {
        return myUserID;
    }

    public void setUserID(int myUserID) {
        this.myUserID = myUserID;
    }

    public boolean getGender() {
        return myGender;
    }

    public void setGender(boolean myGender) {
        this.myGender = myGender;
    }

    public String getName() {
        return myName;
    }

    public void setName(String myName) {
        this.myName = myName;
    }

    public String getEmail() {
        return myEmail;
    }

    public void setEmail(String myEmail) {
        this.myEmail = myEmail;
    }

    public String getPassword() {
        return myPassword;
    }

    public void setPassword(String myPassword) {
        this.myPassword = myPassword;
    }
}
