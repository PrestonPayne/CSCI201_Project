package com.example.ayashimizu.google_test;

import com.google.android.gms.location.places.Place;

/**
 * Created by Zhao on 11/28/2017.
 */

public class PlaceHandler {
    private static Place place;

    public static synchronized void setPlace(Place p){
        place = p;
    }

    public static synchronized Place getPlace(){
        return place;
    }
}
