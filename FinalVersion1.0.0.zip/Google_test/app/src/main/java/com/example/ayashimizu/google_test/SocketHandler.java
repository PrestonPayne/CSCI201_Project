package com.example.ayashimizu.google_test;

import android.util.Log;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Created by Zhao on 11/18/2017.
 */

public class SocketHandler {
    private static Socket socket;
    private static ObjectOutputStream oos;
    private static ObjectInputStream ois;

    public static synchronized Socket getSocket(){
        return socket;
    }

    public static synchronized void setSocket(Socket socket){
        SocketHandler.socket = socket;
        try{
            oos = new ObjectOutputStream(socket.getOutputStream());
            ois = new ObjectInputStream(socket.getInputStream());
        } catch (IOException ioe){
            Log.d("ioe: ", ioe.getMessage());
        }
    }

    public static synchronized ObjectOutputStream getOOS(){
        return oos;
    }

    public static synchronized  ObjectInputStream getOIS(){
        return ois;
    }

}
