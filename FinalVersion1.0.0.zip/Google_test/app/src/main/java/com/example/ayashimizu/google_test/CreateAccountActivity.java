package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import javaClasses.*;

public class CreateAccountActivity extends FragmentActivity {

    private static final String TAG = "CreateAccountActivity";

    private EditText usernameBlock;
    private EditText passwordBlock;
    private EditText emailBlock;
    private EditText ageBlock;
    private Button createButton;
    private Spinner genderBlock;
    private LocTracker locTracker;



    public void init() {
        usernameBlock = findViewById(R.id.username);
        passwordBlock = findViewById(R.id.password);
        emailBlock = findViewById(R.id.email);
        ageBlock = findViewById(R.id.age);
        genderBlock = (Spinner)findViewById(R.id.gender);
        String[] items = new String[]{"Female", "Male"};
        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, items);
        genderBlock.setAdapter(adapter);
        createButton = findViewById(R.id.create);
        createButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {

                String username = usernameBlock.getText().toString();
                String error = "";
                if(username.length() == 0){
                    error = error + "Please enter username" + '\n';
                }

                String password = passwordBlock.getText().toString();
                if(password.length() < 8){
                    error = error + "Password must be longer than 8 characters" + '\n';
                }

                String email = emailBlock.getText().toString();
                if(email.length() < 0){
                    error = error + "Please enter valid email address";
                }

                String ageStr = ageBlock.getText().toString();
                try {
                    int age = Integer.parseInt(ageStr);
                    if(age <= 0 || age > 999){
                        error = error + "Please enter valid age";
                    }
                } catch (NumberFormatException e) {
                    error = error + "Please enter valid age";
                }

                String gender = genderBlock.getSelectedItem().toString();

                if(error.length() == 0){
                    //create a new user obj with the parameters of the fields and add to database
                    //set current user to this newly created user
                    boolean genderBool = false;
                    if(gender.toLowerCase().equals("male")){
                        genderBool = true;
                    }
                    JSONObject obj = new JSONObject();
                    try{
                        obj.put("type", Util.CREATE_NEW_ACOUNT);
                        obj.put("username", username);
                        obj.put("password", password);
                        obj.put("email", email);
                        obj.put("age", Integer.parseInt(ageStr));
                        obj.put("gender", genderBool);
                        obj.put("lat", locTracker.getLattitude());
                        obj.put("lng", locTracker.getLongitude());
                    } catch (JSONException je){
                        Log.d("je", je.getMessage());
                    }
                    new createAccount().execute(obj.toString());
                } else{
                    AlertDialog.Builder alert = new AlertDialog.Builder(CreateAccountActivity.this);
                    alert.setTitle("Invalid Fields");

                    alert.setMessage(error)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    startActivity(new Intent(CreateAccountActivity.this, CreateAccountActivity.class));
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                }

            }
        });

    }

    private class createAccount extends AsyncTask<String, Void, RegisteredUser>{
        @Override
        protected RegisteredUser doInBackground(String... queries) {
            RegisteredUser u = null;
            try{
                SocketHandler.getOOS().writeObject(queries[0]);
                JSONObject response = new JSONObject((String)SocketHandler.getOIS().readObject());
                if(response.getBoolean("isValid")){
                    u = new RegisteredUser(response.getString("username"),
                            response.getInt("age"),
                            response.getInt("id"),
                            response.getString("email"),
                            response.getBoolean("gender"),
                            response.getString("pw"),
                            response.getDouble("lat"),
                            response.getDouble("lng"));
                }
            } catch (ClassNotFoundException cnfe){
                Log.d("cnfe", cnfe.getMessage());
            } catch (IOException ioe){
                Log.d("ioe", ioe.getMessage());
            } finally {
                return u;
            }
        }

        @Override
        protected void onPostExecute(RegisteredUser u){
            if(u == null){
                //TODO: Display Error msg
            } else {
                Intent toy = new Intent(getApplicationContext(), HomePage.class);
                UserHandler.setUser(u);
                startActivity(toy);
            }
        }
    }

    @Override
    protected void onStart(){
        super.onStart();
        locTracker.startLocationUpdates();
    }


    @Override
    protected void onResume() {
        super.onResume();
         locTracker.startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        locTracker.stopLocationUpdates();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        locTracker = new LocTracker(getBaseContext(), CreateAccountActivity.this);
        setContentView(R.layout.activity_create_account);
        init();
    }
}
