package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javaClasses.Event;
import javaClasses.User;
import javaClasses.Util;

public class HomePage extends AppCompatActivity implements OnMapReadyCallback, GoogleMap.OnMarkerClickListener{

    private Button createEventButton;
    private Button search;
    private Button account;
    private Button notifications;
    private Button settings;
    private LocTracker lt;
    private User u;
    private GoogleMap mMap;

    @Override
    protected void onStart(){
        super.onStart();
        lt.startLocationUpdates();
    }

    @Override
    protected void onResume() {
        super.onResume();
        lt.startLocationUpdates();
        u = UserHandler.getUser();
        JSONObject obj = new JSONObject();
        try{
            obj.put("type", Util.GET_EVENTS);
        } catch (JSONException e) {
            Log.d("je", e.getMessage());
        }
        new getEvents().execute(obj.toString());
    }

    @Override
    protected void onPause() {
        super.onPause();
        lt.stopLocationUpdates();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lt = new LocTracker(getBaseContext(), HomePage.this);
        setContentView(R.layout.activity_home_page);
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map2);
        mapFragment.getMapAsync(this);

        init();
    }

    @Override
    protected  void onActivityResult(int requesstCode, int resultCode, Intent data){
        if(requesstCode == 1){
            if(resultCode == RESULT_OK){
                Place place = PlacePicker.getPlace(this, data);
                PlaceHandler.setPlace(place);
                Intent toy = new Intent(getBaseContext(), CreateEvent.class);
                startActivity(toy);
            }
        }
    }

    public void init(){
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(HomePage.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before creating an event")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                while(lt.getLocation() == null){}
                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                double lat = lt.getLattitude();
                double lng = lt.getLongitude();
                builder.setLatLngBounds(new LatLngBounds(new LatLng(lat - 0.1, lng - 0.1), new LatLng(lat + 0.1, lng + 0.1)));
                try{
                    startActivityForResult(builder.build(HomePage.this), 1);
                } catch (GooglePlayServicesNotAvailableException e) {
                    Log.d("gpsnae", e.getMessage());
                } catch (GooglePlayServicesRepairableException e) {
                    Log.d("gpsre", e.getMessage());
                }
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Intent toy = new Intent(HomePage.this, Search.class);
                startActivity(toy);
            }
        });

        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(HomePage.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your account information")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                Intent toy = new Intent(HomePage.this, Account.class);
                toy.putExtra("user", u);
                startActivity(toy);
            }
        });

        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(HomePage.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your notifications settings.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                Intent toy = new Intent(HomePage.this, Notifications.class);
                startActivity(toy);
            }
        });

        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(HomePage.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your settings.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                Intent toy = new Intent(HomePage.this, Settings.class);
                startActivity(toy);
            }
        });


    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        LatLng curr = new LatLng(u.getLat(), u.getLng());
        mMap.addMarker(new MarkerOptions().position(curr)
                .title("You are here"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(curr));
        mMap.setOnMarkerClickListener(this);
    }

    @Override
    public boolean onMarkerClick(Marker marker) {
        Event e = (Event) marker.getTag();
        if(e != null){
            Intent toy = new Intent(HomePage.this, NewEvent.class);
            toy.putExtra("event", e);
            startActivity(toy);
        }

        return false;
    }

    private class getEvents extends AsyncTask<String, Void, ArrayList<Event>>{

        @Override
        protected ArrayList<Event> doInBackground(String... strings) {
            ArrayList<Event> events = new ArrayList<Event>();
            try{
                SocketHandler.getOOS().writeObject(strings[0]);
                SimpleDateFormat sdf = new SimpleDateFormat("MM-dd-yyyy");
                int num = SocketHandler.getOIS().readInt();
                for(int i = 0; i < num; i++){
                    String str = (String)SocketHandler.getOIS().readObject();
                    if(str == null){
                        continue;
                    }
                    JSONObject obj = new JSONObject(str);
                    events.add(new Event(obj.getInt("id"), Time.valueOf(obj.getString("time")), sdf.parse(obj.getString("date")), obj.getString("title"),
                            obj.getString("des"), obj.getDouble("lat"), obj.getDouble("lng")));
                }
            } catch (ClassNotFoundException cnfe){
                Log.d("cnfe", cnfe.getMessage());
            } catch (IOException ioe){
                Log.d("ioe", ioe.getMessage());
            } finally {
                return events;
            }
        }

        @Override
        protected void onPostExecute(ArrayList<Event> events) {
            for(int i = 0; i < events.size(); i++){
                Event e = events.get(i);
                if(e != null){
                    Marker m = mMap.addMarker(new MarkerOptions()
                                                    .position(new LatLng(e.getLat(), e.getLng()))
                                                    .title(e.getTitle())
                                                    .snippet(e.getDateString() + "\n" + e.getDescription()));
                    m.setTag(e);
                }
            }
        }
    }

}
