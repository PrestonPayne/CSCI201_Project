package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.icu.util.TimeUnit;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.TimePicker;
import android.widget.Toast;

import com.google.android.gms.location.places.Place;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import javaClasses.*;

public class CreateEvent extends AppCompatActivity {

    private Button settings;
    private Button search;
    private Button home;
    private Button notifications;
    private Button account;
    private Button create;

    private EditText titleBlock;
    private EditText locationBlock;
    private EditText descriptionBlock;
    private TimePicker simpleTimePicker;
    private DatePicker simpleDatePicker;

    private RegisteredUser u;
    private Place p;

    private int hours;
    private int min;

    private int day;
    private int month;
    private int year;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        u = (RegisteredUser) UserHandler.getUser();
        p = PlaceHandler.getPlace();
        setContentView(R.layout.activity_create_event2);


        init();
    }

    @Override
    protected void onStart(){
        super.onStart();

    }

    public void init(){

        simpleTimePicker=(TimePicker)findViewById(R.id.simpleTimePicker);
        hours = simpleTimePicker.getCurrentHour();
        min = simpleTimePicker.getCurrentMinute();
        simpleTimePicker.setOnTimeChangedListener(new TimePicker.OnTimeChangedListener() {
            @Override
            public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
                hours = hourOfDay;
                min = minute;
            }
        });

        simpleDatePicker = (DatePicker)findViewById(R.id.simpleDatePicker);
        day = simpleDatePicker.getDayOfMonth();
        month = simpleDatePicker.getMonth();
        year = simpleDatePicker.getYear();


        titleBlock = findViewById(R.id.title);
        locationBlock = findViewById(R.id.location);
        locationBlock.setText(p.getAddress());
        descriptionBlock = findViewById(R.id.description);


        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Settings.class);
                startActivity(toy);
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Search.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, HomePage.class);
                startActivity(toy);
            }
        });

        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Notifications.class);
                startActivity(toy);
            }
        });

        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(CreateEvent.this, Account.class);
                startActivity(toy);
            }
        });

        create = findViewById(R.id.create);
        create.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                String title = titleBlock.getText().toString();
                String error = "";
                if(title.length() == 0){
                    error = error + "Please enter title" + '\n';
                }


                String location = locationBlock.getText().toString();
                if(location.length() < 0){
                    error = error + "Please enter location";
                }

                String description = descriptionBlock.getText().toString();
                if(description.length() < 0){
                    error = error + "Please enter description";
                }

                if(error.length() == 0){
                    JSONObject obj = new JSONObject();
                    Date date = new GregorianCalendar(year, month, day).getTime();
                    Time time = new Time(hours, min, 0);
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    try{
                        obj.put("type", Util.CREATE_EVENT);
                        obj.put("time",time.toString());
                        obj.put("date", sdf.format(date));
                        obj.put("title", title);
                        obj.put("des", description);
                        obj.put("lat", p.getLatLng().latitude);
                        obj.put("lng", p.getLatLng().longitude);
                        obj.put("userId", u.getUserID());
                    } catch (JSONException e) {
                        Log.d("je", e.getMessage());
                    }
                    new createEvent().execute(obj.toString());
                } else{
                    AlertDialog.Builder alert = new AlertDialog.Builder(CreateEvent.this);
                    alert.setTitle("Invalid Fields");

                    alert.setMessage(error)
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                    startActivity(new Intent(CreateEvent.this, CreateEvent.class));
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                }

            }
        });
    }

    private class createEvent extends AsyncTask<String, Void, Boolean>{
        @Override
        protected Boolean doInBackground(String... queries) {
            boolean isSuccess = true;
            try{
                SocketHandler.getOOS().writeObject(queries[0]);
                isSuccess = SocketHandler.getOIS().readBoolean();
            } catch (IOException ioe){
                Log.d("ioe", ioe.getMessage());
            } finally {
                return isSuccess;
            }
        }

        @Override
        protected void onPostExecute(Boolean isSuccess){
            if(!isSuccess){
                AlertDialog.Builder alert = new AlertDialog.Builder(CreateEvent.this);
                alert.setTitle("Update Error");

                alert.setMessage("Unable to create event. Please try again")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialog = alert.create();
                dialog.show();
            } else {
                Toast.makeText(getBaseContext(), "Event Created!", Toast.LENGTH_SHORT).show();
                Intent toy = new Intent(getBaseContext(), HomePage.class);
                startActivity(toy);
            }
        }
    }
}
