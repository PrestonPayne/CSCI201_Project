package com.example.ayashimizu.google_test;

import android.location.Location;

import javaClasses.User;

/**
 * Created by Zhao on 11/27/2017.
 */

public class UserHandler {
    private static User user;

    public static synchronized void setUser(User u){
        user = u;
    }

    public static synchronized User getUser(){
        return user;
    }

    public static synchronized void setNewLocation(Location loc){
        if(user != null){
            user.setLat(loc.getLatitude());
            user.setLng(loc.getLongitude());
        }
    }
}
