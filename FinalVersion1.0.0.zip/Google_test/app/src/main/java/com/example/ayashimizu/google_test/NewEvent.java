package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.transition.Transition;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;

import javaClasses.Event;
import javaClasses.RegisteredUser;
import javaClasses.User;
import javaClasses.Util;

public class NewEvent extends AppCompatActivity {

    private Button createEventButton;
    private Button search;
    private Button home;
    private Button notifications;
    private Button settings;
    private Button account;
    private Button join;
    private LocTracker lt;
    private Event e;
    private User u;

    @Override
    protected void onStart(){
        super.onStart();
        lt.startLocationUpdates();
    }

    @Override
    protected void onResume() {
        super.onResume();
        lt.startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        lt.stopLocationUpdates();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_event);
        lt = new LocTracker(getBaseContext(), NewEvent.this);
        u = UserHandler.getUser();
        e = (Event)getIntent().getSerializableExtra("event");
        LinearLayout middle = (LinearLayout) findViewById(R.id.ttt4);
        TextView box = new TextView(this);
        String text = e.getTitle();
        box.setText(text);
        box.setHeight(200);
        box.setWidth(40);
        box.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
        box.setGravity(Gravity.CENTER);
        middle.addView(box);

        TextView dateString = new TextView(this);
        String text2 = e.getDateString();
        dateString.setText(text2);
        dateString.setHeight(70);
        dateString.setWidth(315);
        dateString.setGravity(Gravity.CENTER);
        dateString.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);
        middle.addView(dateString);

        TextView description = new TextView(this);
        String text3 = e.getDescription(); //get string description of event
        description.setText(text3);
        description.setHeight(100);
        description.setWidth(315);
        description.setGravity(Gravity.CENTER);
        description.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);
        middle.addView(description);

        JSONObject obj = new JSONObject();
        try{
            obj.put("type", Util.GET_MEMBER);
            obj.put("id", e.getId());
        } catch (JSONException e1) {
            Log.d("je", e1.getMessage());
        }

        new getMember().execute(obj.toString());

        init();
    }

    private class getMember extends AsyncTask<String, Void, ArrayList<RegisteredUser>>{

        @Override
        protected ArrayList<RegisteredUser> doInBackground(String... strings) {
            ArrayList<RegisteredUser> users = new ArrayList<RegisteredUser>();
            try{
                SocketHandler.getOOS().writeObject(strings[0]);
                int num = SocketHandler.getOIS().readInt();
                for(int i = 0; i < num; i ++){
                    String str = (String)SocketHandler.getOIS().readObject();
                    if(str == null || str.trim().equals("")){
                        continue;
                    }
                    JSONObject response = new JSONObject(str);
                    users.add(new RegisteredUser(response.getString("username"),
                            response.getInt("age"),
                            response.getInt("id"),
                            response.getString("email"),
                            response.getBoolean("gender"),
                            response.getString("pw"),
                            response.getDouble("lat"),
                            response.getDouble("lng")));
                }
            } catch (IOException e1) {
                Log.d("ioe", e1.getMessage());
            } catch (ClassNotFoundException e1) {
                Log.d("cnfe", e1.getMessage());
            } finally {
                return users;
            }
        }

        @Override
        protected void onPostExecute(ArrayList<RegisteredUser> users) {
            LinearLayout middle = (LinearLayout) findViewById(R.id.ttt4);
            if(users.size() > 0){
                LinearLayout event1 = new LinearLayout(NewEvent.this);
                LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,250);
                event1.setLayoutParams(params);
                event1.setOrientation(LinearLayout.VERTICAL);
                event1.setGravity(Gravity.CENTER);

                RegisteredUser creator = users.get(0);
                TextView box = new TextView(NewEvent.this);
                String text = "Creator: " + creator.getName();
                box.setText(text);
                box.setHeight(200);
                box.setWidth(40);
                box.setTextSize(TypedValue.COMPLEX_UNIT_SP, 22);
                box.setGravity(Gravity.CENTER);

                TextView info = new TextView(NewEvent.this);
                String text3 = Integer.toString(creator.getAge()) + ", " + creator.getGenderString();
                info.setText(text3);
                info.setHeight(70);
                info.setWidth(315);
                info.setGravity(Gravity.CENTER);
                info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 20);

                event1.addView(box);
                event1.addView(info);
                middle.addView(event1);
                event1.setOnClickListener(new UserOnClickListener(creator));
                for(int i = 1; i < users.size(); i++){
                    RegisteredUser ru = users.get(i);
                    if(ru != null){
                        LinearLayout event = new LinearLayout(getBaseContext());
                        LinearLayout.LayoutParams params0 = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,150);
                        event.setLayoutParams(params0);
                        event.setOrientation(LinearLayout.VERTICAL);
                        event.setGravity(Gravity.CENTER);

                        TextView name = new TextView(NewEvent.this);
                        String text2 = ru.getName();
                        name.setText(text2);
                        name.setHeight(50);
                        name.setWidth(315);
                        name.setGravity(Gravity.CENTER);
                        name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);

                        TextView info1 = new TextView(NewEvent.this);
                        String text4 = Integer.toString(ru.getAge()) + ", " + ru.getGenderString();
                        info1.setText(text4);
                        info1.setHeight(50);
                        info1.setWidth(315);
                        info1.setGravity(Gravity.CENTER);
                        info1.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);

                        event.addView(name);
                        event.addView(info1);
                        middle.addView(event);
                        event.setOnClickListener(new UserOnClickListener(ru));
                    }
                }
            } else {
                TextView box = new TextView(NewEvent.this);
                String text = "No one has joined this event yet.";
                box.setText(text);
                box.setHeight(200);
                box.setWidth(40);
                box.setTextSize(TypedValue.COMPLEX_UNIT_SP, 25);
                box.setGravity(Gravity.CENTER);
                middle.addView(box);
            }
            if(u.isRegistered()){
                if(!users.contains(u)){
                    join.setVisibility(View.VISIBLE);
                }
            } else {
                join.setVisibility(View.VISIBLE);
            }
        }
    }

    private class joinEvent extends AsyncTask<String, Void, Boolean>{

        @Override
        protected Boolean doInBackground(String... strings) {
            boolean isSuccess = false;
            try{
                SocketHandler.getOOS().writeObject(strings[0]);
                isSuccess = SocketHandler.getOIS().readBoolean();
            } catch (IOException e1) {
                Log.d("ioe", e1.getMessage());
            } finally {
                return isSuccess;
            }
        }

        @Override
        protected void onPostExecute(Boolean isSuccess) {
            if(!isSuccess){
                AlertDialog.Builder alert = new AlertDialog.Builder(NewEvent.this);
                alert.setTitle("Joining Error");

                alert.setMessage("Unable to join event. Please try again")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialog = alert.create();
                dialog.show();
            } else {
                Toast.makeText(getBaseContext(), "Event joined!", Toast.LENGTH_SHORT).show();
                Intent toy = new Intent(getBaseContext(), HomePage.class);
                startActivity(toy);
            }
        }
    }

    private class UserOnClickListener implements View.OnClickListener {
        private RegisteredUser ru;

        public UserOnClickListener(RegisteredUser ru){
            this.ru = ru;
        }

        @Override
        public void onClick(View view) {
            Intent toy = new Intent(NewEvent.this, Account.class);
            toy.putExtra("user", ru);
            startActivity(toy);
        }
    }

    public void init(){
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(NewEvent.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before creating an event")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                while(lt.getLocation() == null){}
                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                double lat = lt.getLattitude();
                double lng = lt.getLongitude();
                builder.setLatLngBounds(new LatLngBounds(new LatLng(lat - 0.1, lng - 0.1), new LatLng(lat + 0.1, lng + 0.1)));
                try{
                    startActivityForResult(builder.build(NewEvent.this), 1);
                } catch (GooglePlayServicesNotAvailableException e) {
                    Log.d("gpsnae", e.getMessage());
                } catch (GooglePlayServicesRepairableException e) {
                    Log.d("gpsre", e.getMessage());
                }
            }
        });

        join = findViewById(R.id.join);
        join.setVisibility(View.INVISIBLE);
        join.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(NewEvent.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before joining events.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                JSONObject obj = new JSONObject();
                try{
                    obj.put("type", Util.JOIN);
                    obj.put("event_id", e.getId());
                    obj.put("user_id", ((RegisteredUser)u).getUserID());
                } catch (JSONException e1) {
                    Log.d("je", e1.getMessage());
                }
                new joinEvent().execute(obj.toString());
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this, Search.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(NewEvent.this, HomePage.class);
                startActivity(toy);
            }
        });

        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(NewEvent.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your notifications settings.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }

                Intent toy = new Intent(NewEvent.this, Notifications.class);
                startActivity(toy);
            }
        });

        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(NewEvent.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your settings.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }

                Intent toy = new Intent(NewEvent.this, Settings.class);
                startActivity(toy);
            }
        });

        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(NewEvent.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your account information")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                Intent toy = new Intent(NewEvent.this,  Account.class);
                startActivity(toy);
            }
        });

    }
}
