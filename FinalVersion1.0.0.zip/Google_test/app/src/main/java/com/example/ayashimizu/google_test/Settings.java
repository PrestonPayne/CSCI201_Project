package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;

import javaClasses.RegisteredUser;
import javaClasses.User;
import javaClasses.Util;

public class Settings extends AppCompatActivity {

    private Button createEventButton;
    private Button search;
    private Button home;
    private Button notifications;
    private Button account;
    private Button logout;
    private EditText newName;
    private Button changeName;
    private LocTracker lt;
    private RegisteredUser u;

    @Override
    protected void onResume() {
        super.onResume();
        lt.startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        lt.stopLocationUpdates();
    }


    @Override
    protected void onStart() {
        super.onStart();
        lt.startLocationUpdates();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);
        u = (RegisteredUser) UserHandler.getUser();
        lt = new LocTracker(getBaseContext(), Settings.this);
        init();

    }

    public void init(){
        //if current user != null
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                while(lt.getLocation() == null){}
                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                double lat = lt.getLattitude();
                double lng = lt.getLongitude();
                builder.setLatLngBounds(new LatLngBounds(new LatLng(lat - 0.1, lng - 0.1), new LatLng(lat + 0.1, lng + 0.1)));
                try{
                    startActivityForResult(builder.build(Settings.this), 1);
                } catch (GooglePlayServicesNotAvailableException e) {
                    Log.d("gpsnae", e.getMessage());
                } catch (GooglePlayServicesRepairableException e) {
                    Log.d("gpsre", e.getMessage());
                }
            }
        });

        search = findViewById(R.id.search);
        search.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, Search.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, HomePage.class);
                startActivity(toy);
            }
        });

        //if current user != null
        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, Notifications.class);
                startActivity(toy);
            }
        });

        //if current user != null
        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, Account.class);
                startActivity(toy);
            }
        });

        logout = findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Settings.this, MainActivity.class);
                UserHandler.setUser(null);
                startActivity(toy);
            }
        });

        //if current user != null
        newName = findViewById(R.id.newName);
        changeName = findViewById(R.id.changeName);
        changeName.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                JSONObject obj = new JSONObject();
                try{
                    obj.put("type", Util.CHANGE_NAME);
                    obj.put("id", u.getUserID());
                    obj.put("name", newName.getText().toString());
                } catch (JSONException e) {
                    Log.d("je", e.getMessage());
                }
                new changeName().execute(obj.toString());
            }
        });
    }

    private class changeName extends AsyncTask<String, Void, Boolean>{

        @Override
        protected Boolean doInBackground(String... strings) {
            boolean isSuccess = false;
            try{
                SocketHandler.getOOS().writeObject(strings[0]);
                isSuccess = SocketHandler.getOIS().readBoolean();
            } catch (IOException e) {
                Log.d("ioe", e.getMessage());
            } finally {
                return  isSuccess;
            }
        }

        @Override
        protected void onPostExecute(Boolean isSuccess) {
            if(!isSuccess){
                AlertDialog.Builder alert = new AlertDialog.Builder(Settings.this);
                alert.setTitle("Unable to change username");

                alert.setMessage("The name has already been taken. Please try again")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialog = alert.create();
                dialog.show();
            } else {
                Toast.makeText(getBaseContext(), "Username changed!", Toast.LENGTH_SHORT).show();
                u.setName(newName.getText().toString());
            }
        }
    }
}
