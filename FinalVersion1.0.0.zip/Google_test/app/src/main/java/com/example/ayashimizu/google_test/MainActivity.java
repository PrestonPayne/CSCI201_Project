package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AlertDialog;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.io.IOException;
import java.net.Socket;

import org.json.*;

import org.json.JSONObject;

import javaClasses.*;

public class MainActivity extends FragmentActivity {

    private Button loginButton;
    private Button createAccountButton;
    private Button unregisteredUserButton;
    private EditText usernameBlock;
    private EditText passwordBlock;
    private LocTracker lt;

    @Override
    protected void onStart(){
        super.onStart();
        UserHandler.setUser(null);
        lt.startLocationUpdates();
    }

    @Override
    protected void onResume() {
        super.onResume();
        lt.startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        lt.stopLocationUpdates();
    }

    public void init() {
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        unregisteredUserButton = findViewById(R.id.unregisteredUserButton);
        usernameBlock = findViewById(R.id.username);
        passwordBlock = findViewById(R.id.password);
        unregisteredUserButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {
                Intent toy = new Intent(MainActivity.this, HomePage.class);
                User u = new User(lt.getLattitude(), lt.getLongitude());
                UserHandler.setUser(u);
                startActivity(toy);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                JSONObject obj = new JSONObject();
                try {
                    obj.put("type", Util.VERIFY_USER);
                    obj.put("username", usernameBlock.getText().toString());
                    obj.put("password", passwordBlock.getText().toString());
                } catch (JSONException je){
                    Log.d("je", je.getMessage());
                }
                new getUser().execute(obj.toString());
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {
                Intent toy = new Intent(MainActivity.this, CreateAccountActivity.class);
                startActivity(toy);

            }
        });
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        if(SocketHandler.getSocket() == null){
            new connectToPort().execute(1234);
        }
        super.onCreate(savedInstanceState);
        lt = new LocTracker(getBaseContext(), MainActivity.this);
        setContentView(R.layout.activity_main);
        init();

    }

    private class getUser extends AsyncTask<String, Void, RegisteredUser>{
        protected RegisteredUser doInBackground(String... queries){
            RegisteredUser u = null;
            try{
                SocketHandler.getOOS().writeObject(queries[0]);
                JSONObject response = new JSONObject((String)SocketHandler.getOIS().readObject());
                if(response.getBoolean("isValid")){
                    u = new RegisteredUser(response.getString("username"),
                            response.getInt("age"),
                            response.getInt("id"),
                            response.getString("email"),
                            response.getBoolean("gender"),
                            response.getString("pw"),
                            response.getDouble("lat"),
                            response.getDouble("lng"));
                }
            } catch (ClassNotFoundException cnfe){
                Log.d("cnfe", cnfe.getMessage());
            } catch (IOException ioe){
                Log.d("ioe", ioe.getMessage());
            } finally {
                return u;
            }
        }

        protected void onPostExecute(RegisteredUser u){
            if(u == null){
                AlertDialog.Builder alert = new AlertDialog.Builder(MainActivity.this);
                alert.setTitle("Username/Password is invalid");

                alert.setMessage("Your username/password combination is invalid. Please try again")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialog = alert.create();
                dialog.show();
            } else {
                Intent toy = new Intent(MainActivity.this,HomePage.class);
                UserHandler.setUser(u);
                startActivity(toy);
            }
        }
    }

    private class connectToPort extends AsyncTask<Integer, Void, Socket> {
        protected Socket doInBackground(Integer... port){
            Socket socket = null;
            try{
                socket = new Socket("10.0.2.2", port[0]);
                SocketHandler.setSocket(socket);
            } catch (IOException ioe){
                Log.d("ioe", ioe.getMessage());
            } finally {
                return socket;
            }
        }

    }
}


