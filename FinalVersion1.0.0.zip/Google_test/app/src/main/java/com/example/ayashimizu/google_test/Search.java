package com.example.ayashimizu.google_test;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.sql.Time;
import java.text.SimpleDateFormat;
import java.util.ArrayList;

import javaClasses.Event;
import javaClasses.RegisteredUser;
import javaClasses.User;
import javaClasses.Util;

public class Search extends AppCompatActivity {

    private Button createEventButton;
    private Button account;
    private Button home;
    private Button notifications;
    private Button settings;
    private User u;
    private LocTracker lt;

    private EditText nameSearch;
    private Button name;
    private String username;

    @Override
    protected void onResume() {
        super.onResume();
        lt.startLocationUpdates();
    }

    @Override
    protected void onPause() {
        super.onPause();
        lt.stopLocationUpdates();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        lt = new LocTracker(getBaseContext(), Search.this);
        setContentView(R.layout.activity_search);
        u = (User) UserHandler.getUser();
        init();
    }

    public void init(){
        //if current user != null
        createEventButton = findViewById(R.id.createEvent);
        createEventButton.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(Search.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before creating an event")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                while(lt.getLocation() == null){}
                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();
                double lat = lt.getLattitude();
                double lng = lt.getLongitude();
                builder.setLatLngBounds(new LatLngBounds(new LatLng(lat - 0.1, lng - 0.1), new LatLng(lat + 0.1, lng + 0.1)));
                try{
                    startActivityForResult(builder.build(Search.this), 1);
                } catch (GooglePlayServicesNotAvailableException e) {
                    Log.d("gpsnae", e.getMessage());
                } catch (GooglePlayServicesRepairableException e) {
                    Log.d("gpsre", e.getMessage());
                }
            }
        });

        //if current user != null
        account = findViewById(R.id.account);
        account.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(Search.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your account information")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                Intent toy = new Intent(Search.this, Account.class);
                startActivity(toy);
            }
        });

        home = findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {

                Intent toy = new Intent(Search.this, HomePage.class);
                startActivity(toy);
            }
        });

        //if current user != null
        notifications = findViewById(R.id.notifications);
        notifications.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(Search.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your notifications settings.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }

                Intent toy = new Intent(Search.this, Notifications.class);
                startActivity(toy);
            }
        });

        settings = findViewById(R.id.settings);
        settings.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                if(!u.isRegistered()){
                    AlertDialog.Builder alert = new AlertDialog.Builder(Search.this);
                    alert.setTitle("You are not registered!");
                    alert.setMessage("Please register an account before accessing your settings.")
                            .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                                public void onClick(DialogInterface dialog, int id) {
                                    dialog.cancel();
                                }
                            });
                    AlertDialog dialog = alert.create();
                    dialog.show();
                    return;
                }
                Intent toy = new Intent(Search.this, Settings.class);
                startActivity(toy);
            }
        });

        name = findViewById(R.id.name);
        name.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                nameSearch = findViewById(R.id.nameSearch);
                username = nameSearch.getText().toString();
                JSONObject obj = new JSONObject();
                try{
                    obj.put("type", Util.SEARCH_USER);
                    obj.put("keyword", username);
                } catch (JSONException e) {
                    Log.d("je", e.getMessage());
                }
                new searchUser().execute(obj.toString());

            }
        });
    }

    private class searchUser extends AsyncTask<String, Void, ArrayList<RegisteredUser>>{

        @Override
        protected ArrayList<RegisteredUser> doInBackground(String... strings) {
            ArrayList<RegisteredUser> users = new ArrayList<RegisteredUser>();
            try{
                SocketHandler.getOOS().writeObject(strings[0]);
                int num = SocketHandler.getOIS().readInt();
                for(int i = 0; i < num; i++){
                    JSONObject response = new JSONObject((String)SocketHandler.getOIS().readObject());
                    users.add(new RegisteredUser(response.getString("username"),
                                                 response.getInt("age"),
                                                 response.getInt("id"),
                                                 response.getString("email"),
                                                 response.getBoolean("gender"),
                                                 response.getString("pw"),
                                                 response.getDouble("lat"),
                                                 response.getDouble("lng")));
                }
            } catch (ClassNotFoundException cnfe){
                Log.d("cnfe", cnfe.getMessage());
            } catch (IOException ioe){
                Log.d("ioe", ioe.getMessage());
            } finally {
                return users;
            }
        }

        @Override
        protected void onPostExecute(ArrayList<RegisteredUser> users){
            if(users.size() > 0){
                LinearLayout middle = (LinearLayout) findViewById(R.id.ttt4);
                for(int i = 2; i < middle.getChildCount(); i++){
                    middle.removeViewAt(i);
                }
                for(int i = 0; i < users.size(); i++){
                    RegisteredUser ru = users.get(i);
                    LinearLayout event1 = new LinearLayout(getBaseContext());
                    LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,150);
                    event1.setLayoutParams(params);
                    event1.setOrientation(LinearLayout.VERTICAL);
                    event1.setGravity(Gravity.CENTER);

                    TextView name = new TextView(Search.this);
                    String text2 = ru.getName();
                    name.setText(text2);
                    name.setHeight(50);
                    name.setWidth(315);
                    name.setGravity(Gravity.CENTER);
                    name.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);

                    TextView info = new TextView(Search.this);
                    String text3 = Integer.toString(ru.getAge()) + ", " + ru.getGenderString();
                    info.setText(text3);
                    info.setHeight(50);
                    info.setWidth(315);
                    info.setGravity(Gravity.CENTER);
                    info.setTextSize(TypedValue.COMPLEX_UNIT_SP, 18);

                    event1.addView(name);
                    event1.addView(info);
                    middle.addView(event1);
                    event1.setOnClickListener(new UserOnClickListener(ru));
                }
            } else {
                AlertDialog.Builder alert = new AlertDialog.Builder(Search.this);
                alert.setTitle("No user is found!");
                alert.setMessage("No user with this name is found. Please try again")
                        .setPositiveButton("OK", new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int id) {
                                dialog.cancel();
                            }
                        });
                AlertDialog dialog = alert.create();
                dialog.show();
                return;
            }
        }
    }

    private class UserOnClickListener implements View.OnClickListener {
        private RegisteredUser ru;

        public UserOnClickListener(RegisteredUser ru){
            this.ru = ru;
        }

        @Override
        public void onClick(View view) {
            Intent toy = new Intent(Search.this, Account.class);
            toy.putExtra("user", ru);
            startActivity(toy);
        }
    }


}
