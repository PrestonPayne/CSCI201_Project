1. Run createDB.sql on mysql workbench to create an empty database.
2. Import Code_Due_Server.zip into eclipse and run main method under Server.java in package server.
3. Import Code_Due.zip into android studio.
4. Either build apk and install it on an android device or use emulator


