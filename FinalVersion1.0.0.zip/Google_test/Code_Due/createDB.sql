DROP DATABASE if EXISTS finalproject;
CREATE DATABASE finalproject;
Use finalproject;

CREATE TABLE User_ (
	user_id INT(11) PRIMARY KEY AUTO_INCREMENT,
    user_name VARCHAR(45) NOT NULL UNIQUE,
    user_pw VARCHAR(45) NOT NULL,
    user_email VARCHAR(45) NOT NULL UNIQUE, 
    user_age INT(3) NOT NULL,
    user_gender BOOLEAN NOT NULL
);

CREATE TABLE Event_ (
	event_id INT(11) PRIMARY KEY AUTO_INCREMENT,
	event_location VARCHAR(100) NOT NULL,
    event_time VARCHAR(20) NOT NULL,
    event_date VARCHAR(20) NULL,
    event_title VARCHAR(100) NOT NULL,
	event_past BOOLEAN NOT NULL,
    event_accessibility INT(1) NOT NULL,
    user_id INT(11) NOT NULL,
    FOREIGN KEY fk1(user_id) REFERENCES User_(user_id)
);

CREATE TABLE Comment_ (
	comment_id INT(11) PRIMARY KEY AUTO_INCREMENT,
    comment_string VARCHAR(200) NOT NULL,
    comment_date VARCHAR(20) NOT NULL,
    comment_time VARCHAR(20) NOT NULL,
    comment_location VARCHAR(100) NOT NULL,
    user_id INT(11) NOT NULL,
    event_id INT(11) NOT NULL,
	FOREIGN KEY fk2(user_id) REFERENCES User_(user_id),
    FOREIGN KEY fk3(event_id) REFERENCES Event_(event_id)
);

CREATE TABLE Event_Member (
	event_id INT(11),
    user_id INT(11),
    FOREIGN KEY fk4(event_id) REFERENCES Event_(event_id),
    FOREIGN KEY fk5user_user_(user_id) REFERENCES User_(user_id),
    PRIMARY KEY(event_id, user_id)
);
