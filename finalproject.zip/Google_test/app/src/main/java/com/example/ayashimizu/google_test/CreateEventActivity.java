package com.example.ayashimizu.google_test;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class CreateEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_event);
    }
}
