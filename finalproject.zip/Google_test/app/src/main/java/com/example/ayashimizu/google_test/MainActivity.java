package com.example.ayashimizu.google_test;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.StrictMode;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.FragmentActivity;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.net.URI;
import java.net.URL;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class MainActivity extends FragmentActivity {

    private Button loginButton;
    private Button createAccountButton;
    private Button unregisteredUserButton;
    private EditText usernameBlock;
    private EditText passwordBlock;
    private String username;
    private String password;



   // ConnectionClass connectionClass;
    ProgressDialog progressDialog;

    public void init() {
        loginButton = findViewById(R.id.loginButton);
        createAccountButton = findViewById(R.id.createAccountButton);
        unregisteredUserButton = findViewById(R.id.unregisteredUserButton);
        usernameBlock = findViewById(R.id.username);
        passwordBlock = findViewById(R.id.password);
        unregisteredUserButton.setOnClickListener(new View.OnClickListener(){

            public void onClick(View v) {

                Intent toy = new Intent(MainActivity.this, MapsActivity.class);
                startActivity(toy);
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {

                Connection conn = null;
                Statement st = null;
                ResultSet rs = null;
                try{
                    StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
                    StrictMode.setThreadPolicy(policy);
                    Class.forName("com.mysql.jdbc.Driver");

                    conn = DriverManager.getConnection("jdbc:mysql://localhost:8080/FinalProject", "root", "");
                    st = conn.createStatement();

                    if(usernameBlock.getText().toString().length() > 0 && passwordBlock.getText().toString().length() > 0 ) {
                        rs = st.executeQuery("SELECT * FROM UserInfo WHERE username='" + usernameBlock.getText().toString() +
                                "' AND password='"+ passwordBlock.getText().toString() + "'" );

                    }
                    else {
                        rs = st.executeQuery("SELECT * FROM UserInfo");
                    }

                }catch(SQLException se){
                    Log.e("ERRO", se.getMessage());
                }catch(ClassNotFoundException e){
                    Log.e("ERRO", e.getMessage());
                }catch(Exception ie){
                    Log.e("ERRO", ie.getMessage());
                }
            }
        });

        createAccountButton.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v) {

                Intent toy = new Intent(MainActivity.this, CreateAccountActivity.class);
                startActivity(toy);

            }
        });
    }



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        //connectionClass = new ConnectionClass();
        init();

    }


//    public class Login extends AsyncTask<String, String, String>{
//        String namestr = usernameBlock.getText().toString();
//        String passstr = passwordBlock.getText().toString();
//        String z = "";
//        boolean isSuccess = false;
//
//        @Override
//        protected String doInBackground(String... params){
//            if(namestr.trim().equals("") || passstr.trim().equals("")){
//                z = "Please fill out all fields";
//            }
//            else
//            {
//                try{
//                    //Connection con = connectionClass.CONN();
//                    if(con == null){
//                        z = "Please check your internet connection";
//                    }
//                    else{
//                        String query = "insert into register values('"+namestr+"','"+passstr+"')";
//                        Statement stmt = con.createStatement();
//                            stmt.executeUpdate(query);
//
//                            z = "Login successful";
//                            isSuccess = true;
//                    }
//                }catch (Exception ie){
//                    isSuccess = false;
//                    z = "Exception" + ie;
//                }
//            }
//            return z;
//        }
//    }



}


