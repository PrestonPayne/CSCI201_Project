package com.example.ayashimizu.google_test;

/**
 * Created by ayashimizu on 11/7/17.
 */

public class LoginPage {
}
